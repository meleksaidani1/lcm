/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2019 MediaTek Inc.
 * Author: Joey Pan <joey.pan@mediatek.com>
 */

#ifndef __LCM_PMIC_H__
#define __LCM_PMIC_H__

#include "lcm_drv.h"
#include "lcm_common.h"

#endif

